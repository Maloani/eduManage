<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inscription de l'Institution - AcadManPro</title>
    <link rel="stylesheet" href="style.css">
</head>
<body>
        <!-- Header with Logo, Social Media Icons, Signup, and Login Buttons -->
        <header class="sticky-header">
        <div class="header-content">
            <div class="logo">
                <img src="img/logo.jpg" alt="AcadManPro Logo">
            </div>
            
            <div class="social-icons">
                <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="mailto:your-email@gmail.com" target="_blank"><i class="fas fa-envelope"></i></a>
                <a href="https://wa.me/your-number" target="_blank"><i class="fab fa-whatsapp"></i></a>
                <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
            </div>

            <div class="auth-buttons">
                <a href="index.php" class="btn-signup"><i class="fas fa-home"></i> Accueil</a>
               
            </div>
        </div>
        
    </header>
    <center>

    <!-- Registration Form for Institutions -->
    <section class="registration-section">
        <h2>Inscription de l'Institution</h2>
        
        <form action="submit_registration.php" method="post" enctype="multipart/form-data">
            
            <!-- Institution Information Section -->
            <label for="institution-name">Nom de l'institution</label>
            <input type="text" id="institution-name" name="institution_name" required>
            
            <label for="institution-type">Type d'institution</label>
            <select id="institution-type" name="institution_type" required>
                <option value="university">Université publique</option>
                <option value="vocational">Université privée</option>
                
            </select>
            
            <label for="email">Email de l'institution</label>
            <input type="text" id="email" name="email" required>
            
            <label for="contact-person">Nom du contact principal</label>
            <input type="text" id="contact-person" name="contact_person" required>
            
            <label for="contact-position">Poste du contact principal</label>
            <input type="text" id="contact-position" name="contact_position" required>

            <label for="phone">Téléphone de l'institution</label>
            <input type="tel" id="phone" name="phone" required>

            
            
            <label for="establishment-year">Année de création</label>
<select id="establishment-year" name="establishment_year" required></select>

<script>
    // Get the current year
    const currentYear = new Date().getFullYear();

    // Get the select element
    const yearSelect = document.getElementById("establishment-year");

    // Generate the options from 1100 to the current year
    for (let year = 1100; year <= currentYear; year++) {
        const option = document.createElement("option");
        option.value = year;
        option.text = year;
        yearSelect.appendChild(option);
    }
</script>

            
           
            <label for="logo">Logo de l'institution</label>
            <input type="file" id="logo" name="logo" accept="image/*" required>

            <label for="adress">Adresse complète de l'institution</label>
            <textarea id="adress" name="adress" required></textarea>


            <!-- License Agreement Section -->
            <div class="license-agreement">
                <p><strong>Contrat de Licence :</strong> En cochant cette case, vous acceptez les termes et conditions de notre contrat de licence pour l'utilisation de la plateforme AcadManPro.</p>
                <input type="checkbox" id="accept-license" name="accept_license" required>
                <label for="accept-license">J'accepte le contrat de licence</label>
            </div>

           
            <!-- Submit Button -->
            <button type="submit" class="btn-validate">Valider</button>
            
            <!-- Link to Login Page if Already Registered -->
            <p>Déjà inscrit? <a href="connexion.php">Connectez-vous ici</a></p>
        </form>
    </section>

</body>
</html>
