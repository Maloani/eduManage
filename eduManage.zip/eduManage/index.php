<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AcadManPro - Accueil</title>
    <link rel="icon" href="img/logo.jpg" type="image/x-icon">
    <!-- Alternative for PNG format -->
    <link rel="icon" href="img/logo.jpg" type="image/png">
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Roboto+Slab:wght@700&display=swap" rel="stylesheet">
</head>
<body>
    <!-- Header with Logo, Social Media Icons, Signup, and Login Buttons -->
    <header class="sticky-header">
        <div class="header-content">
            <div class="logo">
                <img src="img/logo.jpg" alt="AcadManPro Logo">
            </div>
            
            <div class="social-icons">
                <a href="https://facebook.com" target="_blank"><i class="fab fa-facebook-f"></i></a>
                <a href="https://twitter.com" target="_blank"><i class="fab fa-twitter"></i></a>
                <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
                <a href="https://instagram.com" target="_blank"><i class="fab fa-instagram"></i></a>
                <a href="mailto:your-email@gmail.com" target="_blank"><i class="fas fa-envelope"></i></a>
                <a href="https://wa.me/your-number" target="_blank"><i class="fab fa-whatsapp"></i></a>
                <a href="https://linkedin.com" target="_blank"><i class="fab fa-linkedin-in"></i></a>
            </div>

            <div class="auth-buttons">
                <a href="register.php" class="btn-signup"><i class="fas fa-user-plus"></i> Inscription</a>
                <a href="connexion.php" class="btn-login"><i class="fas fa-sign-in-alt"></i> Connexion</a>
            </div>
        </div>
        
    </header>
    
    <!-- Main Content Section with Features Presentation -->
<main>
    <section id="presentation1">
        <h2>Présentation de <span class="highlight">AcadManPro</span></h2>
        <p>Découvrez les fonctionnalités innovantes pour une gestion académique optimisée et un suivi efficace des étudiants.</p>
    </section>


    <section id="presentation">
       
        <div class="features">
            <div class="feature">
                <div class="feature-content">
                    <h3 style='color:red'>Gestion des Services Académiques</h3>
                    <p>Accédez à toutes les ressources académiques en ligne, planifiez des rendez-vous avec les conseillers et restez informé des annonces importantes telles que les convocations aux examens.</p>
                    
                </div>
            </div>

            <div class="feature">
                <div class="feature-content">
                    <h3 style='color:red'>Gestion des Finances</h3>
                    <p>Suivez vos paiements, vos bourses et vos frais de scolarité en un seul endroit avec des notifications pour vous tenir à jour sur les dates de paiement et les nouveaux règlements.</p>
                    
                </div>
            </div>
            <div class="feature">
                <div class="feature-content">
                <h3 style='color:red'>Gestion des Horaires de Cours</h3>
                <p>Consultez et gérez votre emploi du temps. Recevez des notifications pour les changements de planning et intégrez votre emploi du temps dans votre calendrier personnel pour une meilleure organisation.</p>
                   
                </div>
            </div>
            <div class="feature">
                <div class="feature-content">
                <h3 style='color:red'>Gestion des Résultats Académiques</h3>
                <p>Suivez vos performances académiques par semestre ou année et analysez vos résultats pour vous améliorer. Visualisez vos progrès grâce à des graphiques détaillés.</p>
                    
                </div>
            </div>
            
            <div class="feature">
                <div class="feature-content">
                <h3 style='color:red'>Gestion des Travaux des Étudiants</h3>
                <p>Soumettez vos travaux, suivez leur progression et recevez des feedbacks détaillés de vos enseignants pour améliorer vos compétences académiques.</p>
                    
                </div>
            </div>
            <div class="feature">
                <div class="feature-content">
                <h3 style='color:red'>Détection de Plagiat</h3>
                <p>Utilisez notre outil intégré pour vérifier l'originalité de vos travaux avec un rapport détaillé de similarité pour éviter le plagiat et garantir l'intégrité de vos soumissions.</p>
                    
                </div>
            </div>
            <div class="feature">
                <div class="feature-content">
                <h3 style='color:red'>Statistiques des Étudiants</h3>
                <p>Analysez vos résultats et comparez-les avec ceux de vos camarades pour mieux comprendre votre performance académique dans chaque matière.</p>
                    
                </div>
            </div>
            <div class="feature">
                <div class="feature-content">
                <h3 style='color:red'>Gestion des Inscriptions</h3>
                <p>Un processus d'inscription simplifié pour les nouveaux étudiants, avec suivi en ligne de chaque étape, du formulaire initial à la validation finale.</p>
                    
                </div>
            </div>
           
        </div>
    </section>
</main>


    <!-- Footer with Current Year -->
    <footer>
        <p>&copy; <span id="currentYear"></span> AcadManPro. Tous droits réservés.</p>
    </footer>

    <!-- Scroll-to-Top Button -->
    <button onclick="scrollToTop()" id="scrollToTopBtn" title="Retour en haut"><i class="fas fa-arrow-up"></i></button>

    <!-- JavaScript -->
    <script>
        // Automatically update the footer year
        document.getElementById("currentYear").textContent = new Date().getFullYear();

        // Scroll to Top Button
        window.onscroll = function() { scrollFunction(); };

        function scrollFunction() {
            const scrollBtn = document.getElementById("scrollToTopBtn");
            if (document.body.scrollTop > 300 || document.documentElement.scrollTop > 300) {
                scrollBtn.style.display = "block";
            } else {
                scrollBtn.style.display = "none";
            }
        }

        function scrollToTop() {
            window.scrollTo({top: 0, behavior: 'smooth'});
        }
    </script>
</body>
</html>
