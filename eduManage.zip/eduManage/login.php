<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <title>EduManage - Institution Login</title>
    <link rel="stylesheet" href="styles2.css">
</head>
<body>
    <h1>Connexion Institutionnelle</h1>
    <form action="" method="post">
        <label for="email">Email:</label>
        <input type="email" id="email" name="email" required>

        <label for="password">Mot de passe:</label>
        <input type="password" id="password" name="password" required>

        <button type="submit">Se Connecter</button>
    </form>
</body>
</html>
