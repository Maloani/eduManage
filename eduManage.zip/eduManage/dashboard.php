<!DOCTYPE html>
<html lang="fr">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>EduManage - Page d'accueil</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <header>
        <h1>Bienvenue sur EduManage</h1>
        <p>Une plateforme intégrée pour la gestion académique des étudiants</p>
    </header>

    <nav>
        <ul>
            <li><a href="#services-academiques">Services Académiques</a></li>
            <li><a href="#finances">Finances</a></li>
            <li><a href="#horaires-cours">Horaires de Cours</a></li>
            <li><a href="#resultats-academiques">Résultats Académiques</a></li>
            <li><a href="#travaux-etudiants">Travaux des Étudiants</a></li>
            <li><a href="#plagiat">Détection de Plagiat</a></li>
            <li><a href="#statistiques">Statistiques des Étudiants</a></li>
            <li><a href="#inscriptions">Inscriptions</a></li>
        </ul>
    </nav>

    <main>
        <section id="services-academiques">
            <h2>Gestion des Services Académiques</h2>
            <p>Accédez à toutes les ressources académiques en ligne, planifiez des rendez-vous avec les conseillers et restez informé des annonces importantes.</p>
        </section>

        <section id="finances">
            <h2>Gestion des Finances</h2>
            <p>Suivez vos paiements, vos bourses et vos frais de scolarité en un seul endroit avec des notifications pour vous tenir à jour.</p>
        </section>

        <section id="horaires-cours">
            <h2>Gestion des Horaires de Cours</h2>
            <p>Consultez et gérez votre emploi du temps, recevez des notifications pour les changements et intégrez votre planning à vos calendriers.</p>
        </section>

        <section id="resultats-academiques">
            <h2>Gestion des Résultats Académiques</h2>
            <p>Suivez vos performances académiques par semestre ou année et analysez vos résultats pour vous améliorer.</p>
        </section>

        <section id="travaux-etudiants">
            <h2>Gestion des Travaux des Étudiants</h2>
            <p>Soumettez vos travaux, suivez leur progression et recevez des feedbacks de vos enseignants.</p>
        </section>

        <section id="plagiat">
            <h2>Détection de Plagiat</h2>
            <p>Utilisez notre outil intégré pour vérifier l'originalité de vos travaux avec un rapport détaillé de similarité.</p>
        </section>

        <section id="statistiques">
            <h2>Statistiques des Étudiants</h2>
            <p>Analysez vos résultats et comparez-les avec ceux de vos camarades pour mieux comprendre votre performance.</p>
        </section>

        <section id="inscriptions">
            <h2>Gestion des Inscriptions</h2>
            <p>Un processus d'inscription simplifié pour les nouveaux étudiants, avec suivi en ligne de chaque étape.</p>
        </section>
    </main>

    <footer>
        <p>&copy; <span id="currentYear"></span> EduManage. Tous droits réservés.</p>
    </footer>

    <!-- Scripts -->
    <script>
        // Script pour activer/désactiver la barre latérale
        function toggleSidebar() {
            const sidebar = document.getElementById('sidebar');
            sidebar.classList.toggle('active');
        }

        // Script pour mettre à jour l'année automatiquement
        document.getElementById("currentYear").textContent = new Date().getFullYear();
    </script>
</body>
</html>
